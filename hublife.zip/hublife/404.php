<?php get_header(); ?>

<div class="container">

  <div class="row">
      <div class="col text-center">

      <h1>Desculpe, página não econtrada</h1>
    
      </div>
  </div>

    
</div>

<?php get_footer(); ?>