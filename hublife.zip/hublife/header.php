<!doctype html>
<html <?php language_attributes(); ?>>

  <head>
    <!-- Required meta tags -->
    <meta <?php bloginfo('charset'); ?>>
    <meta <?php bloginfo('name'); ?>>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/style.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.theme.default.min.css" />

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/1e4507fb95.js" crossorigin="anonymous"></script>

    <script>
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){

        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});
</script>

    <?php wp_head(); ?>

</head>
  <body>

<!-- Navbar -->
   <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light" role="navigation">
        <div class="container-fluid">
        <a class="navbar-brand"> 
                      <?php
                          $hublife_custom_logo = get_theme_mod('custom_logo');
                          $logo = wp_get_attachment_image_src($hublife_custom_logo, 'full');

                          if(has_custom_logo()) {
                              echo '<img src="' .  esc_url($logo[0]) . '">';
                          } else {
                              echo '<h1 class="m-0">' . get_bloginfo('name'). '</h1>';
                          }
                          
                      ?></a>
          <!-- Brand and toggle get grouped for better mobile display -->
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
             <?php
              wp_nav_menu( array(
                  'theme_location'    => 'primary',
                  'depth'             => 2,
                  'container'         => 'div',
                  'container_class'   => 'collapse navbar-collapse',
                  'container_id'      => 'navbarSupportedContent',
                  'menu_class'        => 'navbar-nav ms-auto mb-2 mb-lg-0',
                  'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                  'walker'            => new WP_Bootstrap_Navwalker()
          ) );
              ?>
       </nav>
  </div>
<!-- Navbar Fim -->